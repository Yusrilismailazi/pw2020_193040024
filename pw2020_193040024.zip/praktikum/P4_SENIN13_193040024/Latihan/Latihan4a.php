<?php 
$i = ["ada","abel","men","pung","nilai"];

 ?>

 <!DOCTYPE html>
 <html lang="en">
 <head>
 	<meta charset="utf-8">
 	<title>Document</title>
 </head>
 <body>
  <table style="border:1px solid black; font-size: 20px" cellpadding="10" cellspacing="10">
  	<tr>
  		<td>
  			<?php  
  			echo "Array $i[0]lah suatu vari$i[1] yang dapat $i[2]am$i[3] banyak $i[4]"
  			?>

  		</td>
  	</tr>
  </table>
 </body>
 </html>