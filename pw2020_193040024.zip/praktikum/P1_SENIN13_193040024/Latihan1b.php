<?php
$angka = 5;

echo "Aku adalah angka $angka";
echo "</br>";
echo "jika aku ditambah 20 , jumlahku sekarang " . $angka +=20;
echo "</br>";
echo "jika aku dikali 4, jumlah ku sekarang", $angka *= 4;
echo "</br>";
echo "jika aku dikurangi 10 , jumlahku sekarang", $angka -= 10;
echo "</br>";
echo "jika aku dibagi 5 ,  maka sisaku sekarang", $angka %= 5;
echo "</br>";


?>
